#ifdef HAS_NCP5623
#include <NCP5623.h>
extern NCP5623 rgb;

#endif