#include <string>
#include <vector>

// Global variables for screen function overlay
std::vector<std::string> functionSymbol;
std::string functionSymbolString;
