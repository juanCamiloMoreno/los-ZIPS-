#include "Observer.h"
#include "configuration.h"
